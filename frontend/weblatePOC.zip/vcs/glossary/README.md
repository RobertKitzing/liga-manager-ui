Translations repository created by Weblate
==========================================

See https://weblate.org/ for more info.
